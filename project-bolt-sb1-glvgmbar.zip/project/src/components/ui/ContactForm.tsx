import React, { useState } from 'react';
import { motion } from 'framer-motion';

const ContactForm: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    message: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real implementation, this would send data to a server
    console.log('Form submitted:', formData);
    alert('Merci pour votre message. Nous vous contacterons rapidement.');
    setFormData({ name: '', phone: '', message: '' });
  };

  return (
    <motion.form 
      className="bg-secondary p-6 shadow-card"
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
      onSubmit={handleSubmit}
    >
      <div className="mb-4">
        <label htmlFor="name" className="block mb-2 font-medium">
          Nom complet
        </label>
        <input
          type="text"
          id="name"
          name="name"
          value={formData.name}
          onChange={handleChange}
          className="w-full px-4 py-2 bg-primary border border-accent text-white focus:outline-none focus:ring-1 focus:ring-white"
          required
        />
      </div>
      
      <div className="mb-4">
        <label htmlFor="phone" className="block mb-2 font-medium">
          Téléphone
        </label>
        <input
          type="tel"
          id="phone"
          name="phone"
          value={formData.phone}
          onChange={handleChange}
          className="w-full px-4 py-2 bg-primary border border-accent text-white focus:outline-none focus:ring-1 focus:ring-white"
          required
        />
      </div>
      
      <div className="mb-6">
        <label htmlFor="message" className="block mb-2 font-medium">
          Message
        </label>
        <textarea
          id="message"
          name="message"
          value={formData.message}
          onChange={handleChange}
          rows={4}
          className="w-full px-4 py-2 bg-primary border border-accent text-white focus:outline-none focus:ring-1 focus:ring-white resize-none"
          required
        ></textarea>
      </div>
      
      <button
        type="submit"
        className="btn btn-primary w-full"
      >
        Envoyer
      </button>
    </motion.form>
  );
};

export default ContactForm;