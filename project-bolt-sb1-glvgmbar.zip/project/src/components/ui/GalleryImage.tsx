import React from 'react';
import { motion } from 'framer-motion';

interface GalleryImageProps {
  src: string;
  alt: string;
}

const GalleryImage: React.FC<GalleryImageProps> = ({ src, alt }) => {
  return (
    <motion.div 
      className="aspect-square overflow-hidden bg-accent"
      whileHover={{ scale: 1.02 }}
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 0.3 }}
    >
      <img 
        src={src} 
        alt={alt} 
        className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-500"
      />
    </motion.div>
  );
};

export default GalleryImage;