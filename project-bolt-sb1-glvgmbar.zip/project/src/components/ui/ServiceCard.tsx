import React from 'react';
import { motion } from 'framer-motion';

interface ServiceCardProps {
  title: string;
  price: string;
  description?: string;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ title, price, description }) => {
  return (
    <motion.div 
      className="card"
      whileHover={{ y: -5 }}
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.3 }}
    >
      <div className="flex justify-between items-center mb-2">
        <h3 className="text-xl font-serif">{title}</h3>
        <span className="text-xl font-medium">{price} €</span>
      </div>
      {description && <p className="text-muted">{description}</p>}
    </motion.div>
  );
};

export default ServiceCard;