import React from 'react';
import { Link } from 'react-router-dom';
import { Scissors, Instagram, Facebook } from 'lucide-react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-secondary py-10">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <Scissors className="w-5 h-5" />
              <span className="text-lg font-serif font-bold">The Barber Box</span>
            </div>
            <p className="text-muted mb-4">
              Salon de coiffure homme haut de gamme à Saran, proposant des prestations de qualité depuis 2019.
            </p>
            <div className="flex space-x-4">
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="text-muted hover:text-white transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="text-muted hover:text-white transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-serif mb-4">Horaires d'ouverture</h3>
            <ul className="text-muted space-y-2">
              <li className="flex justify-between">
                <span>Lundi</span>
                <span>09:00 - 19:00</span>
              </li>
              <li className="flex justify-between">
                <span>Mardi</span>
                <span>09:00 - 19:00</span>
              </li>
              <li className="flex justify-between">
                <span>Mercredi</span>
                <span>09:00 - 19:00</span>
              </li>
              <li className="flex justify-between">
                <span>Jeudi</span>
                <span>09:00 - 19:00</span>
              </li>
              <li className="flex justify-between">
                <span>Vendredi</span>
                <span>09:00 - 19:00</span>
              </li>
              <li className="flex justify-between">
                <span>Samedi</span>
                <span>09:00 - 19:00</span>
              </li>
              <li className="flex justify-between">
                <span>Dimanche</span>
                <span>Fermé</span>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-serif mb-4">Contact</h3>
            <address className="text-muted not-italic space-y-2 mb-4">
              <p>1342 Rue de Montmirail</p>
              <p>45770 Saran</p>
              <p>Tel: 02.38.XX.XX.XX</p>
              <p>Email: contact@thebarberbox.fr</p>
            </address>
            <Link to="/contact" className="btn btn-outline">
              Nous contacter
            </Link>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-10 pt-6 flex flex-col md:flex-row justify-between items-center text-sm text-muted">
          <p>© {currentYear} The Barber Box. Tous droits réservés.</p>
          <div className="flex space-x-4 mt-4 md:mt-0">
            <Link to="/" className="hover:text-white">Mentions légales</Link>
            <Link to="/" className="hover:text-white">Politique de confidentialité</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;