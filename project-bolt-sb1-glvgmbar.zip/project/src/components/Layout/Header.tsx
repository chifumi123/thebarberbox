import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { Menu, X, Scissors } from 'lucide-react';

interface HeaderProps {
  scrolled: boolean;
}

const Header: React.FC<HeaderProps> = ({ scrolled }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const closeMenu = () => {
    setIsMenuOpen(false);
  };

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-primary shadow-md py-3' : 'bg-transparent py-5'
      }`}
    >
      <div className="container flex items-center justify-between">
        <NavLink to="/" className="flex items-center space-x-2" onClick={closeMenu}>
          <Scissors className="w-6 h-6" />
          <span className="text-xl font-serif font-bold">The Barber Box</span>
        </NavLink>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          <NavLink to="/" className="nav-link">
            Accueil
          </NavLink>
          <NavLink to="/prices" className="nav-link">
            Nos Tarifs
          </NavLink>
          <NavLink to="/gallery" className="nav-link">
            Galerie
          </NavLink>
          <NavLink to="/contact" className="nav-link">
            Contact
          </NavLink>
          <a 
            href="#booking" 
            className="btn btn-outline"
            onClick={(e) => {
              e.preventDefault();
              document.getElementById('booking')?.scrollIntoView({ behavior: 'smooth' });
            }}
          >
            Prendre RDV
          </a>
        </nav>

        {/* Mobile Menu Button */}
        <button 
          className="md:hidden text-white focus:outline-none"
          onClick={toggleMenu}
          aria-label="Toggle menu"
        >
          {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 bg-primary shadow-md">
          <div className="container py-4 flex flex-col space-y-4">
            <NavLink to="/" className="nav-link" onClick={closeMenu}>
              Accueil
            </NavLink>
            <NavLink to="/prices" className="nav-link" onClick={closeMenu}>
              Nos Tarifs
            </NavLink>
            <NavLink to="/gallery" className="nav-link" onClick={closeMenu}>
              Galerie
            </NavLink>
            <NavLink to="/contact" className="nav-link" onClick={closeMenu}>
              Contact
            </NavLink>
            <a 
              href="#booking" 
              className="btn btn-outline w-full text-center"
              onClick={(e) => {
                e.preventDefault();
                document.getElementById('booking')?.scrollIntoView({ behavior: 'smooth' });
                closeMenu();
              }}
            >
              Prendre RDV
            </a>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;