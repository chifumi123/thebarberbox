import React from 'react';
import { motion } from 'framer-motion';
import { Scissors } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.pexels.com/photos/1813272/pexels-photo-1813272.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&dpr=1" 
          alt="Barbershop interior" 
          className="w-full h-full object-cover object-center grayscale opacity-40"
        />
        <div className="absolute inset-0 bg-black bg-opacity-70"></div>
      </div>
      
      {/* Content */}
      <div className="container relative z-10 mt-20">
        <div className="max-w-3xl mx-auto text-center">
          <motion.h1 
            className="text-4xl md:text-6xl lg:text-7xl font-serif font-bold mb-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            RENTREZ DANS L'UNIVERS DE LA BOX
          </motion.h1>
          
          <motion.p 
            className="text-lg md:text-xl mb-10 text-gray-300 max-w-2xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            Une expérience unique de coiffure masculine et soins pour l'homme moderne.
            Un espace où style et bien-être se rencontrent pour sublimer votre apparence.
          </motion.p>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <a 
              href="#booking" 
              className="btn btn-primary text-lg px-8 py-4"
              id="booking"
              onClick={(e) => {
                e.preventDefault();
                // In real implementation, this would scroll to booking section or open booking modal
                alert("Fonctionnalité de réservation à implémenter");
              }}
            >
              📅 Prendre rendez-vous
            </a>
            
            <div className="mt-10 flex items-center justify-center">
              <Scissors className="w-5 h-5 mr-2" />
              <span className="text-muted">Depuis 2019</span>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Hero;