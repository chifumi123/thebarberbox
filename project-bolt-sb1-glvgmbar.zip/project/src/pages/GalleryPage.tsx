import React from 'react';
import { motion } from 'framer-motion';
import SectionTitle from '../components/ui/SectionTitle';
import GalleryImage from '../components/ui/GalleryImage';

const GalleryPage: React.FC = () => {
  const galleryImages = [
    {
      src: "https://images.pexels.com/photos/1319460/pexels-photo-1319460.jpeg?auto=compress&cs=tinysrgb&w=800",
      alt: "Barber cutting client's hair"
    },
    {
      src: "https://images.pexels.com/photos/1805600/pexels-photo-1805600.jpeg?auto=compress&cs=tinysrgb&w=800",
      alt: "Man getting beard trimmed"
    },
    {
      src: "https://images.pexels.com/photos/1813272/pexels-photo-1813272.jpeg?auto=compress&cs=tinysrgb&w=800",
      alt: "Barbershop interior"
    },
    {
      src: "https://images.pexels.com/photos/1570806/pexels-photo-1570806.jpeg?auto=compress&cs=tinysrgb&w=800",
      alt: "Barber tools on table"
    },
    {
      src: "https://images.pexels.com/photos/2076930/pexels-photo-2076930.jpeg?auto=compress&cs=tinysrgb&w=800",
      alt: "Barber using razor"
    },
    {
      src: "https://images.pexels.com/photos/1684233/pexels-photo-1684233.jpeg?auto=compress&cs=tinysrgb&w=800",
      alt: "Man after haircut"
    },
    {
      src: "https://images.pexels.com/photos/3998416/pexels-photo-3998416.jpeg?auto=compress&cs=tinysrgb&w=800",
      alt: "Styling men's hair"
    },
    {
      src: "https://images.pexels.com/photos/3998421/pexels-photo-3998421.jpeg?auto=compress&cs=tinysrgb&w=800",
      alt: "Barber working on client"
    },
    {
      src: "https://images.pexels.com/photos/1453005/pexels-photo-1453005.jpeg?auto=compress&cs=tinysrgb&w=800",
      alt: "Classic barbershop interior"
    }
  ];

  return (
    <>
      {/* Header Banner */}
      <div className="relative pt-20 pb-16 bg-secondary">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.pexels.com/photos/1570807/pexels-photo-1570807.jpeg?auto=compress&cs=tinysrgb&w=1920&h=400&dpr=1" 
            alt="Barber shop interior" 
            className="w-full h-full object-cover grayscale opacity-20"
          />
          <div className="absolute inset-0 bg-secondary bg-opacity-80"></div>
        </div>
        
        <div className="container relative z-10 mt-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center"
          >
            <h1 className="text-4xl md:text-5xl font-serif font-bold mb-4">Notre Galerie</h1>
            <p className="text-lg text-muted max-w-2xl mx-auto">
              Découvrez notre savoir-faire et le style qui fait notre réputation.
            </p>
          </motion.div>
        </div>
      </div>
      
      {/* Gallery Section */}
      <section className="py-16 bg-primary">
        <div className="container">
          <SectionTitle 
            title="Nos Réalisations" 
            subtitle="Un aperçu de notre travail et de l'expertise de nos barbiers."
            center={true}
          />
          
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {galleryImages.map((image, index) => (
              <GalleryImage 
                key={index}
                src={image.src}
                alt={image.alt}
              />
            ))}
          </div>
        </div>
      </section>
      
      {/* Instagram Section */}
      <section className="py-16 bg-secondary">
        <div className="container">
          <div className="text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              <h2 className="text-3xl font-serif mb-6">Suivez-nous sur Instagram</h2>
              <p className="text-muted mb-8 max-w-2xl mx-auto">
                Découvrez nos dernières réalisations et actualités en nous suivant sur Instagram.
              </p>
              <a 
                href="https://instagram.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="btn btn-outline px-8 py-4"
              >
                @thebarberbox
              </a>
            </motion.div>
          </div>
        </div>
      </section>
    </>
  );
};

export default GalleryPage;