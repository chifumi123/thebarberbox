import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Scissors, Users, Award, Clock } from 'lucide-react';
import Hero from '../components/sections/Hero';
import SectionTitle from '../components/ui/SectionTitle';

const HomePage: React.FC = () => {
  const features = [
    {
      icon: <Scissors className="w-8 h-8" />,
      title: "Coiffure de précision",
      description: "Nos coiffeurs experts utilisent des techniques avancées pour un résultat impeccable."
    },
    {
      icon: <Users className="w-8 h-8" />,
      title: "Expertise barbe",
      description: "Taille, rasage traditionnel et soins pour une barbe parfaitement entretenue."
    },
    {
      icon: <Award className="w-8 h-8" />,
      title: "Produits premium",
      description: "Sélection rigoureuse de produits haut de gamme pour des résultats exceptionnels."
    },
    {
      icon: <Clock className="w-8 h-8" />,
      title: "Moment de détente",
      description: "Un moment privilégié dans un cadre élégant conçu pour votre confort."
    }
  ];

  return (
    <>
      <Hero />
      
      {/* About Section */}
      <section className="py-20 bg-secondary">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              <SectionTitle 
                title="À propos de The Barber Box" 
                subtitle="Un concept unique où la coiffure masculine rencontre l'élégance et le savoir-faire."
                center={false}
              />
              <p className="text-muted mb-6">
                Fondé en 2019, The Barber Box est né de la passion pour l'art de la coiffure masculine. 
                Notre équipe de barbiers expérimentés s'engage à offrir des prestations de qualité supérieure 
                dans un cadre élégant et masculin où chaque détail est soigné.
              </p>
              <p className="text-muted mb-8">
                Nous utilisons uniquement des produits premium et des techniques modernes pour garantir des 
                résultats exceptionnels, que ce soit pour une coupe tendance, un soin de barbe ou une 
                expérience complète de grooming.
              </p>
              <Link to="/prices" className="btn btn-outline">
                Découvrir nos services
              </Link>
            </motion.div>
            
            <motion.div
              className="relative"
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              <img 
                src="https://images.pexels.com/photos/1319460/pexels-photo-1319460.jpeg?auto=compress&cs=tinysrgb&w=1200&h=800&dpr=1" 
                alt="Barber working" 
                className="w-full h-auto rounded grayscale"
              />
              <div className="absolute -bottom-6 -left-6 bg-primary p-4 rounded">
                <p className="font-serif text-xl">+5 ans</p>
                <p className="text-muted">d'expertise</p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* Features Section */}
      <section className="py-20 bg-primary">
        <div className="container">
          <SectionTitle 
            title="Nos spécialités" 
            subtitle="Découvrez ce qui fait de The Barber Box une référence en matière de coiffure masculine."
            center={true}
          />
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <motion.div 
                key={index} 
                className="card text-center"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <div className="inline-flex items-center justify-center w-16 h-16 bg-accent rounded-full mb-6 mx-auto">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-serif mb-3">{feature.title}</h3>
                <p className="text-muted">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-20 bg-secondary relative">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.pexels.com/photos/1570806/pexels-photo-1570806.jpeg?auto=compress&cs=tinysrgb&w=1920&h=600&dpr=1" 
            alt="Barber tools" 
            className="w-full h-full object-cover grayscale opacity-20"
          />
          <div className="absolute inset-0 bg-secondary bg-opacity-80"></div>
        </div>
        
        <div className="container relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              <h2 className="text-3xl md:text-4xl font-serif mb-6">Prêt à découvrir l'expérience The Barber Box?</h2>
              <p className="text-muted mb-8">
                Réservez dès maintenant et laissez nos experts s'occuper de votre style.
              </p>
              <Link to="/contact" className="btn btn-primary px-8 py-4">
                Prendre rendez-vous
              </Link>
            </motion.div>
          </div>
        </div>
      </section>
    </>
  );
};

export default HomePage;