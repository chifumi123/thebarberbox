import React from 'react';
import { motion } from 'framer-motion';
import SectionTitle from '../components/ui/SectionTitle';
import ServiceCard from '../components/ui/ServiceCard';
import { Link } from 'react-router-dom';

const PricesPage: React.FC = () => {
  const premiumServices = [
    { title: "Forfait détente", price: "65", description: "Coupe détente + Barbe finition lame + Soin visage" },
    { title: "Forfait complet", price: "50", description: "Coupe + Barbe complète" },
    { title: "Forfait express", price: "45", description: "Coupe express + Barbe express" },
  ];
  
  const hairServices = [
    { title: "Shampooing + coupe + coiffage", price: "27" },
    { title: "Coupe express", price: "22" },
    { title: "Rasage crâne", price: "30" },
    { title: "Coupe tondeuse", price: "20" },
  ];
  
  const beardServices = [
    { title: "Barbe complète", price: "25", description: "Taille + finition lame + serviette chaude + soin" },
    { title: "Barbe express", price: "20", description: "Taille + finition" },
    { title: "Rasage traditionnel", price: "30", description: "Serviette chaude + mousse + soin après-rasage" },
  ];
  
  const studentServices = [
    { title: "Coupe étudiant", price: "23", description: "Sur présentation d'un justificatif" },
    { title: "Coupe enfant (jusqu'à 12 ans)", price: "20" },
    { title: "Coupe Barbe Étudiant", price: "35", description: "Sur présentation d'un justificatif" },
  ];
  
  const careServices = [
    { title: "Épilation nez", price: "8" },
    { title: "Épilation oreilles", price: "8" },
    { title: "Épilation sourcils", price: "10" },
    { title: "Soin visage homme", price: "35", description: "Nettoyage + masque + hydratation" },
  ];

  return (
    <>
      {/* Header Banner */}
      <div className="relative pt-20 pb-16 bg-secondary">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.pexels.com/photos/1570807/pexels-photo-1570807.jpeg?auto=compress&cs=tinysrgb&w=1920&h=400&dpr=1" 
            alt="Barber shop interior" 
            className="w-full h-full object-cover grayscale opacity-20"
          />
          <div className="absolute inset-0 bg-secondary bg-opacity-80"></div>
        </div>
        
        <div className="container relative z-10 mt-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center"
          >
            <h1 className="text-4xl md:text-5xl font-serif font-bold mb-4">Nos Tarifs</h1>
            <p className="text-lg text-muted max-w-2xl mx-auto">
              Découvrez nos prestations et tarifs pour une expérience sur mesure.
            </p>
          </motion.div>
        </div>
      </div>
      
      {/* Premium Services */}
      <section className="py-16 bg-primary">
        <div className="container">
          <SectionTitle 
            title="Forfaits Premium" 
            subtitle="Profitez d'une expérience complète avec nos forfaits signature."
            center={true}
          />
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {premiumServices.map((service, index) => (
              <ServiceCard 
                key={index}
                title={service.title}
                price={service.price}
                description={service.description}
              />
            ))}
          </div>
        </div>
      </section>
      
      {/* Hair Services */}
      <section className="py-16 bg-secondary">
        <div className="container">
          <SectionTitle 
            title="Coiffure Homme" 
            subtitle="Des coupes tendance réalisées avec expertise."
            center={true}
          />
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {hairServices.map((service, index) => (
              <ServiceCard 
                key={index}
                title={service.title}
                price={service.price}
                description={service.description}
              />
            ))}
          </div>
        </div>
      </section>
      
      {/* Beard Services */}
      <section className="py-16 bg-primary">
        <div className="container">
          <SectionTitle 
            title="Service Barbe" 
            subtitle="Prenez soin de votre barbe avec nos services dédiés."
            center={true}
          />
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {beardServices.map((service, index) => (
              <ServiceCard 
                key={index}
                title={service.title}
                price={service.price}
                description={service.description}
              />
            ))}
          </div>
        </div>
      </section>
      
      {/* Student Services */}
      <section className="py-16 bg-secondary">
        <div className="container">
          <SectionTitle 
            title="Étudiants / Enfants" 
            subtitle="Des tarifs adaptés pour les plus jeunes."
            center={true}
          />
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {studentServices.map((service, index) => (
              <ServiceCard 
                key={index}
                title={service.title}
                price={service.price}
                description={service.description}
              />
            ))}
          </div>
        </div>
      </section>
      
      {/* Care Services */}
      <section className="py-16 bg-primary">
        <div className="container">
          <SectionTitle 
            title="Soins Homme" 
            subtitle="Des soins complets pour sublimer votre apparence."
            center={true}
          />
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {careServices.map((service, index) => (
              <ServiceCard 
                key={index}
                title={service.title}
                price={service.price}
                description={service.description}
              />
            ))}
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-16 bg-secondary">
        <div className="container">
          <div className="text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              <h2 className="text-3xl font-serif mb-6">Prêt à vous faire chouchouter?</h2>
              <p className="text-muted mb-8 max-w-2xl mx-auto">
                Prenez rendez-vous dès maintenant et bénéficiez de l'expertise de nos barbiers professionnels.
              </p>
              <Link to="/contact" className="btn btn-primary px-8 py-4">
                Prendre rendez-vous
              </Link>
            </motion.div>
          </div>
        </div>
      </section>
    </>
  );
};

export default PricesPage;