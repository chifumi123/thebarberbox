import React from 'react';
import { motion } from 'framer-motion';
import SectionTitle from '../components/ui/SectionTitle';
import ContactForm from '../components/ui/ContactForm';
import { MapPin, Phone, Clock, Mail } from 'lucide-react';

const ContactPage: React.FC = () => {
  const openingHours = [
    { day: "Lundi", hours: "09:00 - 19:00" },
    { day: "Mardi", hours: "09:00 - 19:00" },
    { day: "Mercredi", hours: "09:00 - 19:00" },
    { day: "Jeudi", hours: "09:00 - 19:00" },
    { day: "Vendredi", hours: "09:00 - 19:00" },
    { day: "Samedi", hours: "09:00 - 19:00" },
    { day: "Dimanche", hours: "Fermé" },
  ];

  return (
    <>
      {/* Header Banner */}
      <div className="relative pt-20 pb-16 bg-secondary">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.pexels.com/photos/1570807/pexels-photo-1570807.jpeg?auto=compress&cs=tinysrgb&w=1920&h=400&dpr=1" 
            alt="Barber shop interior" 
            className="w-full h-full object-cover grayscale opacity-20"
          />
          <div className="absolute inset-0 bg-secondary bg-opacity-80"></div>
        </div>
        
        <div className="container relative z-10 mt-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center"
          >
            <h1 className="text-4xl md:text-5xl font-serif font-bold mb-4">Contact</h1>
            <p className="text-lg text-muted max-w-2xl mx-auto">
              Prenez rendez-vous ou contactez-nous pour toute information.
            </p>
          </motion.div>
        </div>
      </div>
      
      {/* Contact Info Section */}
      <section className="py-16 bg-primary">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div>
              <SectionTitle 
                title="Informations pratiques" 
                subtitle="Toutes les informations dont vous avez besoin pour nous trouver et nous contacter."
                center={false}
              />
              
              <div className="space-y-8">
                <motion.div 
                  className="flex items-start"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5 }}
                >
                  <div className="bg-accent p-3 rounded-full mr-4">
                    <MapPin className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-serif mb-2">Adresse</h3>
                    <p className="text-muted">1342 Rue de Montmirail</p>
                    <p className="text-muted">45770 Saran</p>
                    <a 
                      href="https://maps.google.com" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="inline-block mt-2 text-white hover:underline"
                    >
                      Voir sur Google Maps
                    </a>
                  </div>
                </motion.div>
                
                <motion.div 
                  className="flex items-start"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: 0.1 }}
                >
                  <div className="bg-accent p-3 rounded-full mr-4">
                    <Phone className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-serif mb-2">Téléphone</h3>
                    <p className="text-muted">02.38.XX.XX.XX</p>
                    <a 
                      href="tel:0238XXXXXX" 
                      className="btn btn-outline mt-2"
                    >
                      Appeler maintenant
                    </a>
                  </div>
                </motion.div>
                
                <motion.div 
                  className="flex items-start"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                >
                  <div className="bg-accent p-3 rounded-full mr-4">
                    <Mail className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-serif mb-2">Email</h3>
                    <p className="text-muted">contact@thebarberbox.fr</p>
                  </div>
                </motion.div>
                
                <motion.div 
                  className="flex items-start"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: 0.3 }}
                >
                  <div className="bg-accent p-3 rounded-full mr-4">
                    <Clock className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-serif mb-4">Horaires d'ouverture</h3>
                    <div className="space-y-2">
                      {openingHours.map((item, index) => (
                        <div key={index} className="flex justify-between border-b border-accent pb-2">
                          <span className="text-white">{item.day}</span>
                          <span className="text-muted">{item.hours}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              </div>
            </div>
            
            <div>
              <SectionTitle 
                title="Envoyez-nous un message" 
                subtitle="Une question ou une demande particulière ? Contactez-nous via ce formulaire."
                center={false}
              />
              
              <ContactForm />
            </div>
          </div>
        </div>
      </section>
      
      {/* Map Section */}
      <section className="py-0 bg-primary">
        <div className="h-96 w-full">
          <iframe 
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2673.0927112570317!2d1.8836204!3d47.9372025!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e4fab8301c48ab%3A0xe24bb7122c7be7c4!2sRue%20de%20Montmirail%2C%2045770%20Saran!5e0!3m2!1sfr!2sfr!4v1710333322084!5m2!1sfr!2sfr" 
            width="100%" 
            height="100%" 
            style={{ border: 0 }} 
            allowFullScreen 
            loading="lazy" 
            referrerPolicy="no-referrer-when-downgrade"
            title="The Barber Box location"
            className="grayscale"
          ></iframe>
        </div>
      </section>
    </>
  );
};

export default ContactPage;